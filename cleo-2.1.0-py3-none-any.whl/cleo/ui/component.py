from __future__ import annotations


class Component:
    name: str = "<unnamed_component>"
