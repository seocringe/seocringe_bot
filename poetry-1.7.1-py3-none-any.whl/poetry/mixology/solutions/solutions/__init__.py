from __future__ import annotations

from poetry.mixology.solutions.solutions.python_requirement_solution import (
    PythonRequirementSolution,
)


__all__ = ["PythonRequirementSolution"]
